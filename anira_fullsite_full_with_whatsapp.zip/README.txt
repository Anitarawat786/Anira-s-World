Anira's World - Full Functional Website (Express backend + static frontend)
Location: /mnt/data/anira_fullsite_full

How to run locally:
1. Install Node.js (v16+).
2. In terminal:
   cd backend
   npm install
   npm start
3. Open http://localhost:5000

Features:
- Home, About, Gallery, Shop, Contact sections on a single-page frontend.
- Backend APIs: GET /api/products, GET /api/products/:id, POST /api/contact
- Admin image upload at POST /api/admin/upload (multipart/form-data, field 'image') which saves under frontend/public/images
- Products stored in backend/data/products.json (edit to add your products)
- Contact submissions saved to backend/data/contacts.json

Next steps I can do for you:
- Replace product details with your real product list (titles, descriptions, prices, Payhip links)
- Add PayPal/UPI payment integration or a proper shopping cart
- Deploy to Render (backend) + Vercel (frontend) and set custom domain

