const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const DATA_DIR = path.join(__dirname, 'data');
const PRODUCTS_FILE = path.join(DATA_DIR, 'products.json');
const CONTACTS_FILE = path.join(DATA_DIR, 'contacts.json');

if (!fs.existsSync(PRODUCTS_FILE)) {
  fs.writeFileSync(PRODUCTS_FILE, JSON.stringify([], null, 2));
}
if (!fs.existsSync(CONTACTS_FILE)) {
  fs.writeFileSync(CONTACTS_FILE, JSON.stringify([], null, 2));
}

// Serve frontend static files
app.use('/', express.static(path.join(__dirname, '..', 'frontend', 'public')));

// API: get all products
app.get('/api/products', (req, res) => {
  const products = JSON.parse(fs.readFileSync(PRODUCTS_FILE, 'utf8'));
  res.json(products);
});

// API: get product by id
app.get('/api/products/:id', (req, res) => {
  const id = req.params.id;
  const products = JSON.parse(fs.readFileSync(PRODUCTS_FILE, 'utf8'));
  const p = products.find(x => x.id === id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  res.json(p);
});

// API: add contact (stores to contacts.json)
app.post('/api/contact', (req, res) => {
  const body = req.body;
  const contacts = JSON.parse(fs.readFileSync(CONTACTS_FILE, 'utf8'));
  contacts.push({ id: Date.now().toString(), ...body, createdAt: new Date().toISOString() });
  fs.writeFileSync(CONTACTS_FILE, JSON.stringify(contacts, null, 2));
  res.json({ status: 'ok' });
});

// Simple admin: upload product images (optional)
const uploadDir = path.join(__dirname, '..', 'frontend', 'public', 'images');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const storage = multer.diskStorage({ destination: uploadDir, filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname) });
const upload = multer({ storage });
app.post('/api/admin/upload', upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file' });
  const url = '/images/' + req.file.filename;
  res.json({ url });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log('Backend listening on port', PORT));
