async function fetchProducts() {
  const res = await fetch('/api/products');
  const data = await res.json();
  return data;
}

function createCard(p) {
  const div = document.createElement('div');
  div.className = 'card';
  const img = document.createElement('img');
  img.src = p.image || '/images/placeholder.jpg';
  img.alt = p.title;
  const h = document.createElement('h3'); h.textContent = p.title;
  const desc = document.createElement('p'); desc.textContent = p.description;
  const meta = document.createElement('div'); meta.innerHTML = `<strong>${p.price}</strong> • ${p.size}`;
  const btn = document.createElement('a'); btn.className='btn'; btn.href = p.buy_link || '#'; btn.textContent = 'Buy';
  div.appendChild(img); div.appendChild(h); div.appendChild(desc); div.appendChild(meta); div.appendChild(btn);
  return div;
}

async function render() {
  const products = await fetchProducts();
  const galleryGrid = document.getElementById('galleryGrid');
  const productsGrid = document.getElementById('productsGrid');
  galleryGrid.innerHTML = '';
  productsGrid.innerHTML = '';
  products.forEach(p => {
    // gallery items
    const gcard = createCard(p);
    galleryGrid.appendChild(gcard.cloneNode(true));
    // shop items
    productsGrid.appendChild(createCard(p));
  });
}

document.getElementById('contactForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = {};
  fd.forEach((v,k) => payload[k]=v);
  const res = await fetch('/api/contact', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
  if (res.ok) {
    document.getElementById('contactStatus').textContent = 'Message sent. Thank you!';
    e.target.reset();
  } else {
    document.getElementById('contactStatus').textContent = 'Failed to send message.';
  }
});

render();
