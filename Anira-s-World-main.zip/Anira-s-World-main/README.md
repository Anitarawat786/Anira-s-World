# Anira-s-World
A creative project showcasing Lippan Kaam (Mud and Mirror Work) – the traditional mural art form of Kutch, Gujarat. This repository includes patterns, digital recreations, design inspirations, and resources to preserve and promote this cultural heritage through modern mediums.
